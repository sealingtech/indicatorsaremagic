﻿$host.ui.RawUI.WindowTitle = "scenario17_looper"

$sleeptime = 10
$url = "http://springkarts.com/flower/car/firmware.php"

#uploads file to box
function downloadFile {
$boundary = [guid]::NewGuid().ToString()
$headers = @{}
$headers.Add("cache-control","no-cache")

$enc = [System.Text.Encoding]::GetEncoding("utf-8")
#creating the formdata manually
$template = "
--$boundary
Content-Disposition: form-data; name=""file""; filename="""+$filename.Name+"""
"+$filebodytemplate+"
--$boundary
Content-Disposition: form-data; name=""metadata""
{""name"":"""+$filename.Name+""",""parent"":{""id"":"""+$folderid+"""}}
--$boundary--"

$proxyUri = [Uri]$null
$proxy = [System.Net.WebRequest]::GetSystemWebProxy()
if ($proxy)
{
    $proxy.Credentials = [System.Net.CredentialCache]::DefaultCredentials
    $proxyUri = $proxy.GetProxy("$server$url")
}



#mail upload process beins with Invoke-RestMethod
try{
if ("$proxyUri" -ne "$server$url")
{
    $download_file = Invoke-RestMethod -Uri $url -Method GET -Headers $headers  -Verbose -UseDefaultCredentials -Proxy $proxyUri -ProxyUseDefaultCredentials
} else {
    $download_file = Invoke-RestMethod -Uri $url -Method GET -Headers $headers  -Verbose
}

Write-Host $download_file
}
catch [Exception] {
Write-Host $_.Exception
$exception = $_.ErrorDetails 

switch ($exception.status) {
409 { Write-Host "name exists"}
}
}
}

#accesstoken
$accessToken = "paste accesstoken here"
#provide file full path and the parent folder ID
DO { downloadfile; sleep $sleeptime;} while ($true)
